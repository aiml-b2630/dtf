"""
Sample Data Generator for DTF
Grounding: Problem Brief #106 Section 7
A sample dataset containing 30 to 50 realistic entries representing Duplicate Text Finder records,
formatted in CSV and JSON, containing varied test cases (normal entries, boundary values, and edge conditions).
"""

import random
from datetime import datetime, timedelta
from pathlib import Path
from core.data_models import TextRecord
from core.finder_engine import FinderEngine
from core.persistence import PersistenceManager
from config import DEFAULT_CSV_PATH, DEFAULT_JSON_PATH

def generate_sample_dataset():
    categories = ["Academic", "Code Snippet", "Productivity", "Documentation", "General"]

    # Base text templates with exact duplicate copies intentionally inserted
    text_templates = [
        # Academic entries with exact duplicate copies
        ("In academic and everyday environments, stakeholders frequently experience friction when attempting to compare text entries.", "Academic", "thesis_intro.txt"),
        ("In academic and everyday environments, stakeholders frequently experience friction when attempting to compare text entries.", "Academic", "literature_review_v2.docx"),
        ("Quantum computing leverages superposition and entanglement to perform complex computations exponentially faster than classical computers.", "Academic", "physics_paper_final.pdf"),
        ("Quantum computing leverages superposition and entanglement to perform complex computations exponentially faster than classical computers.", "Academic", "conference_abstract.txt"),
        ("Deep neural networks rely on backpropagation to optimize weights against a specified loss function.", "Academic", "ai_course_notes.txt"),

        # Code Snippets with exact duplicates
        ("def calculate_factorial(n):\n    return 1 if n <= 1 else n * calculate_factorial(n - 1)", "Code Snippet", "utils.py"),
        ("def calculate_factorial(n):\n    return 1 if n <= 1 else n * calculate_factorial(n - 1)", "Code Snippet", "math_helpers.py"),
        ("import json\nwith open('data.json', 'r') as f:\n    data = json.load(f)", "Code Snippet", "loader.py"),
        ("import json\nwith open('data.json', 'r') as f:\n    data = json.load(f)", "Code Snippet", "script_backup.py"),
        ("SELECT user_id, COUNT(*) FROM user_logs GROUP BY user_id HAVING COUNT(*) > 10;", "Code Snippet", "analytics_query.sql"),

        # Productivity & Notes
        ("Action Items: 1. Review PR #104. 2. Update sprint backlog. 3. Schedule design sync for Thursday.", "Productivity", "meeting_notes_nov24.md"),
        ("Action Items: 1. Review PR #104. 2. Update sprint backlog. 3. Schedule design sync for Thursday.", "Productivity", "slack_dump.txt"),
        ("Quarterly objectives: Increase user retention by 15% and reduce p99 API latency below 200ms.", "Productivity", "okrs_2026.md"),
        ("Quarterly objectives: Increase user retention by 15% and reduce p99 API latency below 200ms.", "Productivity", "executive_deck_notes.txt"),
        ("Don't forget to submit the monthly expense reimbursement before the end of the day on Friday.", "Productivity", "reminders.txt"),

        # Documentation
        ("Duplicate Text Finder is a focused, accessible Python application engineered to streamline data handling, validate entries, and present actionable summaries.", "Documentation", "README.md"),
        ("Duplicate Text Finder is a focused, accessible Python application engineered to streamline data handling, validate entries, and present actionable summaries.", "Documentation", "user_guide.pdf"),
        ("All API requests must include a Bearer Token in the Authorization HTTP header.", "Documentation", "api_spec.md"),
        ("All API requests must include a Bearer Token in the Authorization HTTP header.", "Documentation", "postman_collection.json"),
        ("To execute the test suite, run pytest -v under the root project directory.", "Documentation", "contributing.md"),

        # General
        ("The quick brown fox jumps over the lazy dog.", "General", "test_file_1.txt"),
        ("The quick brown fox jumps over the lazy dog.", "General", "test_file_2.txt"),
        ("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.", "General", "lorem.txt"),
        ("Python 3.10 standard library provides standard modules datetime, math, csv, json, and tkinter.", "General", "tech_stack.txt"),
        ("Automated reading and writing of structured records to JSON/CSV files ensuring data survives program restarts.", "General", "brief_excerpt.txt")
    ]

    # Additional unique entries to bring total to 40 records
    extra_unique = [
        ("Machine learning models require robust feature engineering and validation splitting.", "Academic", "ml_notes.txt"),
        ("The standard normal distribution has a mean of zero and variance of one.", "Academic", "stats_handout.pdf"),
        ("Flask is a lightweight WSGI web application framework in Python.", "Code Snippet", "web_app.py"),
        ("docker-compose up -d --build", "Code Snippet", "deploy_script.sh"),
        ("Weekly sync agenda: Project status, blocker resolution, release schedule.", "Productivity", "agenda.md"),
        ("Please review the attached security compliance matrix before deployment.", "Documentation", "sec_policy.txt"),
        ("Zero dependency execution ensures seamless deployment on any standard Python environment.", "Documentation", "specs.md"),
        ("Edge case test: Single word entry.", "General", "edge_case_1.txt"),
        ("Special characters test: !@#$%^&*()_+~`|}{[]:;?><,./-=", "General", "edge_case_2.txt"),
        ("Multi-line paragraph test:\nLine 1: Entry point\nLine 2: Business Logic Engine\nLine 3: Executive Summary", "General", "edge_case_3.txt"),
        ("System audit trail tracks creation timestamps, content hashes, and status flags.", "Productivity", "audit_notes.txt"),
        ("Defensive input validation prevents blank entries and non-conforming types.", "Documentation", "validation_spec.md"),
        ("Record query engine filters records by category, keyword, or duplicate flag.", "Documentation", "query_spec.md"),
        ("Threshold warning indicators highlight high duplicate percentages.", "Documentation", "warning_spec.md"),
        ("Hackathon Mentor Guide Project #106 Duplicate Text Finder.", "Academic", "mentor_guide.pdf")
    ]

    all_raw = text_templates + extra_unique

    records = []
    base_time = datetime.now() - timedelta(days=10)

    for idx, item in enumerate(all_raw, start=1):
        rec_id = f"REC-{idx:03d}"
        text_content, cat, src = item
        created_dt = (base_time + timedelta(hours=idx * 5)).isoformat()
        rec = TextRecord(
            record_id=rec_id,
            text_content=text_content,
            category=cat,
            source_name=src,
            created_at=created_dt,
            notes=f"Sample record #{idx} generated for DTF demo."
        )
        records.append(rec)

    # Run Finder Engine to process duplicate flags & group IDs
    records, dup_groups = FinderEngine.analyze_records(records)

    # Save to JSON and CSV
    PersistenceManager.save_to_json(records, DEFAULT_JSON_PATH)
    PersistenceManager.save_to_csv(records, DEFAULT_CSV_PATH)
    print(f"Successfully generated {len(records)} sample records ({len(dup_groups)} duplicate groups).")

if __name__ == "__main__":
    generate_sample_dataset()
