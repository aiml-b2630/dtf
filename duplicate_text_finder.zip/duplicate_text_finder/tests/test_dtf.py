"""
Unit & End-to-End Test Suite for Duplicate Text Finder (DTF)
Grounding: Problem Brief #106 Section 6 Step 8
Seed realistic test datasets and execute end-to-end user journey validation.
"""

import unittest
from pathlib import Path
import tempfile
import json
import shutil
import sys

# Ensure root directory is in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.data_models import TextRecord
from core.finder_engine import FinderEngine
from core.validator import InputValidator
from core.persistence import PersistenceManager
from core.query_engine import QueryEngine
from core.summary import SummaryGenerator
from core.exporter import SummaryExporter

class TestDuplicateTextFinder(unittest.TestCase):

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_duplicate_detection_logic(self):
        rec1 = TextRecord(record_id="REC-001", text_content="Duplicate Text Entry", category="Academic")
        rec2 = TextRecord(record_id="REC-002", text_content="duplicate text entry  ", category="General")  # normalized match
        rec3 = TextRecord(record_id="REC-003", text_content="Unique Entry Content", category="General")

        records, dup_groups = FinderEngine.analyze_records([rec1, rec2, rec3])

        self.assertTrue(rec1.duplicate_flag)
        self.assertTrue(rec2.duplicate_flag)
        self.assertFalse(rec3.duplicate_flag)
        self.assertEqual(len(dup_groups), 1)

    def test_input_validation(self):
        is_val, msg = InputValidator.validate_text_entry("   ")
        self.assertFalse(is_val)

        is_val_ok, msg_ok = InputValidator.validate_text_entry("Valid input content")
        self.assertTrue(is_val_ok)

    def test_persistence_json(self):
        json_path = self.test_dir / "test_records.json"
        rec = TextRecord(record_id="REC-100", text_content="Test JSON Persistence")
        
        ok, msg = PersistenceManager.save_to_json([rec], json_path)
        self.assertTrue(ok)

        loaded, load_msg = PersistenceManager.load_from_json(json_path)
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].record_id, "REC-100")

    def test_corrupted_json_recovery(self):
        json_path = self.test_dir / "corrupt.json"
        with open(json_path, 'w') as f:
            f.write("{ invalid json formatting ...")

        loaded, msg = PersistenceManager.load_from_json(json_path)
        self.assertEqual(len(loaded), 0)
        self.assertIn("Corrupted file", msg)

    def test_query_engine(self):
        rec1 = TextRecord(record_id="REC-001", text_content="Quantum Physics Paper", category="Academic")
        rec2 = TextRecord(record_id="REC-002", text_content="Python Script", category="Code Snippet")

        results = QueryEngine.search_records([rec1, rec2], keyword="quantum")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].record_id, "REC-001")

    def test_summary_and_export(self):
        rec1 = TextRecord(record_id="REC-001", text_content="Duplicate Item", category="General")
        rec2 = TextRecord(record_id="REC-002", text_content="Duplicate Item", category="General")
        records, _ = FinderEngine.analyze_records([rec1, rec2])

        summary = SummaryGenerator.generate_summary(records)
        self.assertEqual(summary['duplicate_records'], 2)

        md_path = self.test_dir / "summary.md"
        ok, msg = SummaryExporter.export_markdown_summary(summary, records, md_path)
        self.assertTrue(ok)
        self.assertTrue(md_path.exists())

if __name__ == "__main__":
    unittest.main()
