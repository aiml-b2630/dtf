"""
Graphical User Interface (Tkinter) for Duplicate Text Finder
Grounding: Problem Brief #106 Section 4 (Stretch Features: Interactive TUI/GUI Enhancement)
Optional lightweight Graphical Interface for visual menu navigation and analysis.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import sys

# Ensure parent path is in sys.path when running app_gui directly
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import DEFAULT_JSON_PATH, DEFAULT_CSV_PATH, CATEGORIES, EXPORTS_DIR
from core.data_models import TextRecord
from core.finder_engine import FinderEngine
from core.persistence import PersistenceManager
from core.query_engine import QueryEngine
from core.summary import SummaryGenerator
from core.exporter import SummaryExporter
from core.validator import InputValidator

class DTFGuiApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Duplicate Text Finder (DTF) - Python for Good #106")
        self.root.geometry("980x680")
        self.root.minsize(800, 550)

        self.records = []
        self.active_file = DEFAULT_JSON_PATH

        self._setup_ui()
        self.load_dataset(self.active_file)

    def _setup_ui(self):
        # Top Header Banner
        header = tk.Frame(self.root, bg="#1E293B", height=60)
        header.pack(fill=tk.X, side=tk.TOP)

        title_label = tk.Label(
            header,
            text="🔍 Duplicate Text Finder (DTF)",
            font=("Helvetica", 16, "bold"),
            fg="#F8FAFC",
            bg="#1E293B",
            anchor="w"
        )
        title_label.pack(side=tk.LEFT, padx=15, pady=10)

        subtitle_label = tk.Label(
            header,
            text="Hackathon Project #106 | Zero-Dependency Python Tool",
            font=("Helvetica", 10, "italic"),
            fg="#94A3B8",
            bg="#1E293B"
        )
        subtitle_label.pack(side=tk.RIGHT, padx=15, pady=10)

        # Tab Control
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Tab 1: Records & Search
        self.tab_records = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_records, text="📋 Record Manager")
        self._build_records_tab()

        # Tab 2: New Entry & File Scanner
        self.tab_add = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_add, text="➕ Add Entry / Scan File")
        self._build_add_tab()

        # Tab 3: Executive Summary & Analytics
        self.tab_summary = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_summary, text="📊 Analytics & Summary")
        self._build_summary_tab()

        # Bottom Status Bar
        self.status_bar = tk.Label(
            self.root,
            text="Ready.",
            bd=1,
            relief=tk.SUNKEN,
            anchor=tk.W,
            font=("Helvetica", 9),
            bg="#F1F5F9"
        )
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def _build_records_tab(self):
        # Controls frame
        controls = ttk.Frame(self.tab_records)
        controls.pack(fill=tk.X, padx=10, pady=5)

        ttk.Label(controls, text="Search:").pack(side=tk.LEFT, padx=5)
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(controls, textvariable=self.search_var, width=25)
        self.search_entry.pack(side=tk.LEFT, padx=5)
        self.search_entry.bind("<KeyRelease>", lambda e: self.filter_tree())

        ttk.Label(controls, text="Category:").pack(side=tk.LEFT, padx=(15, 5))
        self.cat_filter_var = tk.StringVar(value="All")
        cat_choices = ["All"] + CATEGORIES
        cat_combobox = ttk.Combobox(controls, textvariable=self.cat_filter_var, values=cat_choices, state="readonly", width=14)
        cat_combobox.pack(side=tk.LEFT, padx=5)
        cat_combobox.bind("<<ComboboxSelected>>", lambda e: self.filter_tree())

        ttk.Label(controls, text="Status:").pack(side=tk.LEFT, padx=(15, 5))
        self.status_filter_var = tk.StringVar(value="All")
        status_combobox = ttk.Combobox(
            controls,
            textvariable=self.status_filter_var,
            values=["All", "Duplicates Only", "Unique Only"],
            state="readonly",
            width=15
        )
        status_combobox.pack(side=tk.LEFT, padx=5)
        status_combobox.bind("<<ComboboxSelected>>", lambda e: self.filter_tree())

        btn_reload = ttk.Button(controls, text="🔄 Reload File", command=lambda: self.load_dataset(self.active_file))
        btn_reload.pack(side=tk.RIGHT, padx=5)

        # Treeview Table
        tree_frame = ttk.Frame(self.tab_records)
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        cols = ("record_id", "duplicate_flag", "group_id", "category", "source_name", "length", "text_snippet")
        self.tree = ttk.Treeview(tree_frame, columns=cols, show="headings", selectmode="browse")

        self.tree.heading("record_id", text="ID")
        self.tree.heading("duplicate_flag", text="Status")
        self.tree.heading("group_id", text="Group ID")
        self.tree.heading("category", text="Category")
        self.tree.heading("source_name", text="Source")
        self.tree.heading("length", text="Len")
        self.tree.heading("text_snippet", text="Text Content Snippet")

        self.tree.column("record_id", width=70, anchor="center")
        self.tree.column("duplicate_flag", width=90, anchor="center")
        self.tree.column("group_id", width=100, anchor="center")
        self.tree.column("category", width=110, anchor="center")
        self.tree.column("source_name", width=140, anchor="w")
        self.tree.column("length", width=50, anchor="e")
        self.tree.column("text_snippet", width=380, anchor="w")

        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    def _build_add_tab(self):
        frame = ttk.LabelFrame(self.tab_add, text="Create New Record Entry", padding=15)
        frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)

        ttk.Label(frame, text="Category:").grid(row=0, column=0, sticky="w", pady=5)
        self.entry_cat_var = tk.StringVar(value=CATEGORIES[0])
        ttk.Combobox(frame, textvariable=self.entry_cat_var, values=CATEGORIES, state="readonly", width=25).grid(row=0, column=1, sticky="w", pady=5)

        ttk.Label(frame, text="Source Name:").grid(row=1, column=0, sticky="w", pady=5)
        self.entry_source_var = tk.StringVar(value="GUI Entry")
        ttk.Entry(frame, textvariable=self.entry_source_var, width=35).grid(row=1, column=1, sticky="w", pady=5)

        ttk.Label(frame, text="Text Content:").grid(row=2, column=0, sticky="nw", pady=5)
        self.text_input = tk.Text(frame, width=65, height=10, wrap=tk.WORD)
        self.text_input.grid(row=2, column=1, sticky="w", pady=5)

        btn_submit = ttk.Button(frame, text="💾 Save Record & Scan Duplicates", command=self.add_record_action)
        btn_submit.grid(row=3, column=1, sticky="e", pady=15)

    def _build_summary_tab(self):
        top_btn_frame = ttk.Frame(self.tab_summary)
        top_btn_frame.pack(fill=tk.X, padx=15, pady=10)

        ttk.Button(top_btn_frame, text="📝 Export Markdown Summary", command=self.export_md_action).pack(side=tk.LEFT, padx=5)
        ttk.Button(top_btn_frame, text="📄 Export Text Audit Log", command=self.export_log_action).pack(side=tk.LEFT, padx=5)
        ttk.Button(top_btn_frame, text="📊 Export CSV Report", command=self.export_csv_action).pack(side=tk.LEFT, padx=5)

        self.summary_text = tk.Text(self.tab_summary, wrap=tk.WORD, font=("Courier", 10), bg="#0F172A", fg="#38BDF8", padding=10)
        self.summary_text.pack(fill=tk.BOTH, expand=True, padx=15, pady=10)

    def load_dataset(self, file_path: Path):
        self.active_file = file_path
        if file_path.suffix.lower() == ".json":
            self.records, msg = PersistenceManager.load_from_json(file_path)
        else:
            self.records, msg = PersistenceManager.load_from_csv(file_path)

        self.records, _ = FinderEngine.analyze_records(self.records)
        self.filter_tree()
        self.update_summary_display()
        self.set_status(msg)

    def filter_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        kw = self.search_var.get()
        cat = self.cat_filter_var.get()
        st = self.status_filter_var.get()

        dup_only = True if st == "Duplicates Only" else (False if st == "Unique Only" else None)
        filtered = QueryEngine.search_records(self.records, keyword=kw, category=cat, duplicate_only=dup_only)

        for r in filtered:
            status_str = "DUPLICATE" if r.duplicate_flag else "Clean"
            grp = r.duplicate_group_id if r.duplicate_group_id else "-"
            snip = r.text_content.replace('\n', ' ')
            if len(snip) > 60:
                snip = snip[:57] + "..."
            self.tree.insert("", tk.END, values=(r.record_id, status_str, grp, r.category, r.source_name, r.length, snip))

    def update_summary_display(self):
        summary = SummaryGenerator.generate_summary(self.records)
        self.summary_text.delete("1.0", tk.END)

        lines = [
            "================================================================================",
            "                DUPLICATE TEXT FINDER - EXECUTIVE ANALYTICS SUMMARY",
            "================================================================================",
            f" Total Records Analyzed:     {summary['total_records']}",
            f" Unique Records Count:       {summary['unique_records']}",
            f" Exact Duplicate Entries:    {summary['duplicate_records']}",
            f" Duplicate Ratio (%):        {summary['duplicate_ratio_pct']}%",
            f" Flagged Duplicate Groups:   {summary['duplicate_groups_count']}",
            "--------------------------------------------------------------------------------",
            f" Average Text Length:        {summary['avg_text_length']} chars",
            f" Maximum Text Length:        {summary['max_text_length']} chars",
            f" Minimum Text Length:        {summary['min_text_length']} chars",
            "--------------------------------------------------------------------------------",
            " CATEGORY DISTRIBUTION:"
        ]
        for cat, count in summary.get('category_breakdown', {}).items():
            lines.append(f"   • {cat:<20}: {count} records")

        if summary.get('warnings'):
            lines.extend(["--------------------------------------------------------------------------------", " SYSTEM WARNINGS:"])
            for w in summary['warnings']:
                lines.append(f"   ⚠️  {w}")

        lines.append("================================================================================")
        self.summary_text.insert("1.0", "\n".join(lines))

    def add_record_action(self):
        txt = self.text_input.get("1.0", tk.END).strip()
        is_valid, err_msg = InputValidator.validate_text_entry(txt)
        if not is_valid:
            messagebox.showerror("Validation Error", err_msg)
            return

        cat = self.entry_cat_var.get()
        src = self.entry_source_var.get().strip() or "GUI Entry"
        new_id = f"REC-{(len(self.records) + 1):03d}"

        new_rec = TextRecord(record_id=new_id, text_content=txt, category=cat, source_name=src)
        self.records.append(new_rec)
        self.records, dup_groups = FinderEngine.analyze_records(self.records)

        # Persist
        if self.active_file.suffix.lower() == ".json":
            PersistenceManager.save_to_json(self.records, self.active_file)
        else:
            PersistenceManager.save_to_csv(self.records, self.active_file)

        self.filter_tree()
        self.update_summary_display()
        self.text_input.delete("1.0", tk.END)

        if new_rec.duplicate_flag:
            messagebox.showwarning(
                "Duplicate Detected",
                f"Entry saved! ⚠️ Exact duplicate match found and flagged under group '{new_rec.duplicate_group_id}'."
            )
        else:
            messagebox.showinfo("Success", f"Entry '{new_id}' added successfully. Status: Unique.")

    def export_md_action(self):
        summary = SummaryGenerator.generate_summary(self.records)
        out_path = EXPORTS_DIR / "executive_summary.md"
        ok, msg = SummaryExporter.export_markdown_summary(summary, self.records, out_path)
        if ok:
            messagebox.showinfo("Export Successful", f"{msg}\nFile saved at:\n{out_path}")
        else:
            messagebox.showerror("Export Failed", msg)

    def export_log_action(self):
        summary = SummaryGenerator.generate_summary(self.records)
        out_path = EXPORTS_DIR / "system_audit_log.txt"
        ok, msg = SummaryExporter.export_text_audit_log(self.records, summary, out_path)
        if ok:
            messagebox.showinfo("Export Successful", f"{msg}\nFile saved at:\n{out_path}")
        else:
            messagebox.showerror("Export Failed", msg)

    def export_csv_action(self):
        out_path = EXPORTS_DIR / "records_export.csv"
        ok, msg = SummaryExporter.export_csv_report(self.records, out_path)
        if ok:
            messagebox.showinfo("Export Successful", f"{msg}\nFile saved at:\n{out_path}")
        else:
            messagebox.showerror("Export Failed", msg)

    def set_status(self, text: str):
        self.status_bar.config(text=f" Status: {text}")

def main():
    root = tk.Tk()
    app = DTFGuiApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
