"""
Record Query & Search Engine
Grounding: Problem Brief #106 Section 3 (Record Query & Search)
Keyword and category-based filtering tools allowing quick retrieval of stored information.
"""

from typing import List, Optional
from core.data_models import TextRecord

class QueryEngine:

    @staticmethod
    def search_records(
        records: List[TextRecord],
        keyword: Optional[str] = None,
        category: Optional[str] = None,
        duplicate_only: Optional[bool] = None
    ) -> List[TextRecord]:
        results = records

        if category and category != "All":
            cat_clean = category.strip().lower()
            results = [r for r in results if r.category.lower() == cat_clean]

        if duplicate_only is not None:
            results = [r for r in results if r.duplicate_flag == duplicate_only]

        if keyword:
            kw = keyword.strip().lower()
            results = [
                r for r in results
                if kw in r.text_content.lower() or kw in r.source_name.lower() or kw in r.notes.lower()
            ]

        return results
