"""
Local Data Persistence Module
Grounding: Problem Brief #106 Section 3, 4, 8
Handles reading and writing of CSV and JSON datasets.
Encapsulates operations in try-except blocks detecting FileNotFoundError & JSONDecodeError,
automatically restoring/creating clean initial dataset templates.
"""

import csv
import json
from pathlib import Path
from typing import List, Tuple
from core.data_models import TextRecord

class PersistenceManager:

    @staticmethod
    def save_to_json(records: List[TextRecord], file_path: Path) -> Tuple[bool, str]:
        try:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            data = [rec.to_dict() for rec in records]
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True, f"Successfully saved {len(records)} records to '{file_path.name}'."
        except Exception as e:
            return False, f"Error saving JSON: {str(e)}"

    @staticmethod
    def load_from_json(file_path: Path) -> Tuple[List[TextRecord], str]:
        """
        Loads records from JSON. If missing or corrupted, creates/returns clean initial state.
        """
        if not file_path.exists():
            return [], f"Warning: Storage file '{file_path.name}' not found. Initialized new empty dataset."

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                raw_data = json.load(f)
            
            if not isinstance(raw_data, list):
                raise ValueError("JSON root element must be a list.")

            records = [TextRecord.from_dict(item) for item in raw_data if isinstance(item, dict)]
            return records, f"Loaded {len(records)} records from '{file_path.name}'."

        except (json.JSONDecodeError, ValueError) as err:
            # Handle corrupted files per Section 8 Tip
            backup_path = file_path.with_suffix(".json.corrupt.bak")
            try:
                file_path.rename(backup_path)
                notice = f"Corrupted file '{file_path.name}' backed up to '{backup_path.name}'. Re-created clean storage template."
            except Exception:
                notice = f"Corrupted file '{file_path.name}' detected ({str(err)}). Re-created clean storage template."
            return [], notice
        except Exception as err:
            return [], f"Error loading JSON file: {str(err)}"

    @staticmethod
    def save_to_csv(records: List[TextRecord], file_path: Path) -> Tuple[bool, str]:
        try:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            fieldnames = [
                "record_id", "text_content", "category", "source_name",
                "created_at", "duplicate_flag", "duplicate_group_id",
                "notes", "length", "content_hash"
            ]
            with open(file_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for rec in records:
                    writer.writerow(rec.to_dict())
            return True, f"Successfully saved {len(records)} records to CSV '{file_path.name}'."
        except Exception as e:
            return False, f"Error saving CSV: {str(e)}"

    @staticmethod
    def load_from_csv(file_path: Path) -> Tuple[List[TextRecord], str]:
        if not file_path.exists():
            return [], f"Warning: CSV file '{file_path.name}' not found. Initialized empty dataset."

        try:
            records = []
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # Clean up booleans from CSV string representation
                    dup_flag = str(row.get('duplicate_flag', '')).lower() in ['true', '1', 'yes']
                    row['duplicate_flag'] = dup_flag
                    records.append(TextRecord.from_dict(row))
            return records, f"Loaded {len(records)} records from CSV '{file_path.name}'."
        except Exception as err:
            return [], f"Error reading CSV file '{file_path.name}': {str(err)}"
