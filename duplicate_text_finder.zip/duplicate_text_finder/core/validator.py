"""
Defensive Input Validation & Sanitization Module
Grounding: Problem Brief #106 Section 3 & Section 8
- Real-time sanitization and range checks to ensure domain constraint compliance.
- Defensive handling against non-conforming types and blank terminal inputs.
"""

import re
from pathlib import Path
from typing import Optional, List, Tuple

class InputValidator:

    @staticmethod
    def sanitize_text(raw_text: str) -> str:
        if not raw_text:
            return ""
        # Remove null bytes and clean control characters while preserving standard spacing/newlines
        sanitized = raw_text.replace('\0', '').strip()
        return sanitized

    @staticmethod
    def validate_text_entry(text: str, min_len: int = 1, max_len: int = 50000) -> Tuple[bool, str]:
        clean = InputValidator.sanitize_text(text)
        if not clean:
            return False, "Error: Text content cannot be blank or contain only whitespace."
        if len(clean) < min_len:
            return False, f"Error: Text length ({len(clean)}) is below minimum requirement ({min_len})."
        if len(clean) > max_len:
            return False, f"Error: Text length ({len(clean)}) exceeds maximum allowed ({max_len})."
        return True, "Valid"

    @staticmethod
    def validate_category(category: str, allowed_categories: List[str]) -> Tuple[bool, str]:
        clean_cat = InputValidator.sanitize_text(category)
        if clean_cat not in allowed_categories:
            return False, f"Error: Category must be one of {allowed_categories}."
        return True, "Valid"

    @staticmethod
    def validate_file_path(file_path_str: str, must_exist: bool = True) -> Tuple[bool, str]:
        clean_path = InputValidator.sanitize_text(file_path_str)
        if not clean_path:
            return False, "Error: File path cannot be empty."
        path = Path(clean_path)
        if must_exist and not path.exists():
            return False, f"Error: Target file does not exist at '{clean_path}'."
        if must_exist and not path.is_file():
            return False, f"Error: Path '{clean_path}' is not a regular file."
        return True, "Valid"

    @staticmethod
    def prompt_valid_text(prompt_msg: str) -> str:
        while True:
            val = input(prompt_msg)
            is_valid, msg = InputValidator.validate_text_entry(val)
            if is_valid:
                return InputValidator.sanitize_text(val)
            print(f"  [!] {msg}")

    @staticmethod
    def prompt_valid_menu_choice(prompt_msg: str, valid_choices: List[str]) -> str:
        while True:
            val = input(prompt_msg).strip()
            if val in valid_choices:
                return val
            print(f"  [!] Invalid selection '{val}'. Please enter one of: {', '.join(valid_choices)}")
