"""
Core Business Logic Engine
Grounding: Problem Brief #106 Section 3 & Section 6 Step 4
Computational algorithms specifically programmed to compare text entries and flag exact duplicates in a list or file.
"""

from typing import List, Dict, Tuple, Set, Any
from collections import defaultdict
from core.data_models import TextRecord

class FinderEngine:
    """
    Core processing engine to compare text entries, group exact matches,
    and update duplicate flags and group IDs.
    """

    @staticmethod
    def analyze_records(records: List[TextRecord]) -> Tuple[List[TextRecord], Dict[str, List[TextRecord]]]:
        """
        Analyzes a list of TextRecord instances:
        - Calculates normalized content hashes.
        - Identifies exact duplicate text groups.
        - Updates duplicate_flag and duplicate_group_id on records.
        Returns updated records and a mapping of group_id -> duplicate records list.
        """
        hash_groups: Dict[str, List[TextRecord]] = defaultdict(list)
        for rec in records:
            hash_groups[rec.content_hash].append(rec)

        duplicate_groups: Dict[str, List[TextRecord]] = {}
        group_counter = 1

        for content_hash, rec_list in hash_groups.items():
            if len(rec_list) > 1:
                group_id = f"DUP-GRP-{group_counter:03d}"
                group_counter += 1
                duplicate_groups[group_id] = rec_list
                for rec in rec_list:
                    rec.duplicate_flag = True
                    rec.duplicate_group_id = group_id
            else:
                for rec in rec_list:
                    rec.duplicate_flag = False
                    rec.duplicate_group_id = None

        return records, duplicate_groups

    @staticmethod
    def scan_file_for_duplicates(file_path: str) -> Dict[str, Any]:
        """
        Scans an arbitrary plain text file line-by-line, detecting exact duplicate lines.
        Returns line count, unique lines, duplicate lines, and detailed duplicate line groups.
        """
        line_map = defaultdict(list)
        total_lines = 0

        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            for line_no, raw_line in enumerate(f, start=1):
                clean_line = raw_line.strip()
                if not clean_line:
                    continue  # Ignore empty lines
                total_lines += 1
                norm_key = " ".join(clean_line.lower().split())
                line_map[norm_key].append((line_no, raw_line.rstrip('\n')))

        duplicate_lines = {}
        dup_count = 0
        for norm_key, line_entries in line_map.items():
            if len(line_entries) > 1:
                dup_count += len(line_entries) - 1
                duplicate_lines[norm_key] = {
                    "occurrences": len(line_entries),
                    "line_numbers": [idx for idx, _ in line_entries],
                    "sample_text": line_entries[0][1]
                }

        return {
            "file_path": file_path,
            "total_non_empty_lines": total_lines,
            "unique_lines_count": len(line_map),
            "duplicate_lines_count": dup_count,
            "duplicate_groups_count": len(duplicate_lines),
            "duplicate_details": duplicate_lines
        }
