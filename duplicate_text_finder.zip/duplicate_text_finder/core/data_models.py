"""
Core Data Models for Duplicate Text Finder (DTF)
Grounding: Problem Brief #106 Section 6 - Step 2 (Data structures & Dataclasses)
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
import hashlib
from typing import Optional, Dict, Any

@dataclass
class TextRecord:
    record_id: str
    text_content: str
    category: str = "General"
    source_name: str = "Manual Entry"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    duplicate_flag: bool = False
    duplicate_group_id: Optional[str] = None
    notes: str = ""

    @property
    def length(self) -> int:
        return len(self.text_content)

    @property
    def normalized_text(self) -> str:
        # Standardized normalization: lowercased, stripped, collapsed spaces
        return " ".join(self.text_content.strip().lower().split())

    @property
    def content_hash(self) -> str:
        return hashlib.sha256(self.normalized_text.encode('utf-8')).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['length'] = self.length
        d['content_hash'] = self.content_hash
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TextRecord':
        return cls(
            record_id=str(data.get('record_id', '')),
            text_content=str(data.get('text_content', '')),
            category=str(data.get('category', 'General')),
            source_name=str(data.get('source_name', 'Manual Entry')),
            created_at=str(data.get('created_at', datetime.now().isoformat())),
            duplicate_flag=bool(data.get('duplicate_flag', False)),
            duplicate_group_id=data.get('duplicate_group_id'),
            notes=str(data.get('notes', ''))
        )
