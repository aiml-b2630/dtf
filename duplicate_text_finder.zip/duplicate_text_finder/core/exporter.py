"""
Multi-Format Summary Export Module
Grounding: Problem Brief #106 Section 4 (Multi-Format Summary Export)
Generates structured Markdown reports, plain-text audit logs, and standardized CSV reports for external review.
"""

from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Tuple
from core.data_models import TextRecord
from core.summary import SummaryGenerator
from core.persistence import PersistenceManager

class SummaryExporter:

    @staticmethod
    def export_markdown_summary(summary: Dict[str, Any], records: List[TextRecord], output_path: Path) -> Tuple[bool, str]:
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            md_lines = [
                "# Duplicate Text Finder (DTF) - Executive Summary Report",
                f"*Generated on: {now_str}*",
                "",
                "## 1. Key Performance Indicators",
                f"- **Total Records Analyzed:** {summary['total_records']}",
                f"- **Unique Entries:** {summary['unique_records']}",
                f"- **Exact Duplicate Entries:** {summary['duplicate_records']}",
                f"- **Duplicate Ratio:** `{summary['duplicate_ratio_pct']}%`",
                f"- **Duplicate Groups Flagged:** {summary['duplicate_groups_count']}",
                "",
                "## 2. Text Content Metrics",
                f"- **Average Text Length:** {summary['avg_text_length']} characters",
                f"- **Maximum Text Length:** {summary['max_text_length']} characters",
                f"- **Minimum Text Length:** {summary['min_text_length']} characters",
                "",
                "## 3. Category Distribution",
            ]

            for cat, cnt in summary.get('category_breakdown', {}).items():
                md_lines.append(f"- **{cat}:** {cnt} records")

            if summary.get('warnings'):
                md_lines.extend(["", "## 4. Threshold & System Warnings"])
                for w in summary['warnings']:
                    md_lines.append(f"- ⚠️ **{w}**")

            # Table of flagged duplicate records
            dup_recs = [r for r in records if r.duplicate_flag]
            md_lines.extend(["", "## 5. Flagged Duplicate Records Detail", ""])
            if dup_recs:
                md_lines.append("| Record ID | Group ID | Category | Source | Text Snippet |")
                md_lines.append("| --- | --- | --- | --- | --- |")
                for r in dup_recs:
                    snip = r.text_content[:40].replace('\n', ' ') + ("..." if len(r.text_content) > 40 else "")
                    md_lines.append(f"| {r.record_id} | {r.duplicate_group_id} | {r.category} | {r.source_name} | {snip} |")
            else:
                md_lines.append("*No duplicate records detected in the dataset.*")

            with open(output_path, 'w', encoding='utf-8') as f:
                f.write("\n".join(md_lines))

            return True, f"Exported Markdown summary to '{output_path.name}'."
        except Exception as e:
            return False, f"Error exporting Markdown: {str(e)}"

    @staticmethod
    def export_text_audit_log(records: List[TextRecord], summary: Dict[str, Any], output_path: Path) -> Tuple[bool, str]:
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            lines = [
                "================================================================================",
                "DUPLICATE TEXT FINDER (DTF) - SYSTEM AUDIT LOG",
                f"TIMESTAMP: {now_str}",
                "================================================================================",
                f"TOTAL RECORDS IN AUDIT: {summary['total_records']}",
                f"DUPLICATES IDENTIFIED:  {summary['duplicate_records']} ({summary['duplicate_ratio_pct']}%)",
                "--------------------------------------------------------------------------------",
                "RECORD AUDIT TRAIL:",
                "--------------------------------------------------------------------------------"
            ]

            for rec in records:
                status = f"FLAGGED [{rec.duplicate_group_id}]" if rec.duplicate_flag else "CLEAN/UNIQUE"
                lines.append(
                    f"[{rec.created_at}] ID: {rec.record_id:<8} | STATUS: {status:<20} | CAT: {rec.category:<12} | SRC: {rec.source_name}"
                )
                lines.append(f"  CONTENT HASH: {rec.content_hash}")
                lines.append(f"  TEXT SNIPPET:  {rec.text_content[:80]}")
                lines.append("-" * 80)

            with open(output_path, 'w', encoding='utf-8') as f:
                f.write("\n".join(lines))

            return True, f"Exported text audit log to '{output_path.name}'."
        except Exception as e:
            return False, f"Error exporting Audit Log: {str(e)}"

    @staticmethod
    def export_csv_report(records: List[TextRecord], output_path: Path) -> Tuple[bool, str]:
        return PersistenceManager.save_to_csv(records, output_path)
