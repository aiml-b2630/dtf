"""
Executive Summary & Analytics Module
Grounding: Problem Brief #106 Section 3 & Section 4
- Executive Summary Generation: aggregation module computing totals, averages, status indicators, and key trends.
- Threshold Warning Indicators: warning flags highlighting breach of duplicate thresholds or dataset volume limits.
"""

from typing import List, Dict, Any
from collections import Counter
from core.data_models import TextRecord
from config import DUPLICATE_RATIO_WARNING_THRESHOLD, MAX_RECOMMENDED_RECORDS

class SummaryGenerator:

    @staticmethod
    def generate_summary(records: List[TextRecord]) -> Dict[str, Any]:
        total_records = len(records)
        if total_records == 0:
            return {
                "total_records": 0,
                "unique_records": 0,
                "duplicate_records": 0,
                "duplicate_ratio_pct": 0.0,
                "duplicate_groups_count": 0,
                "avg_text_length": 0.0,
                "max_text_length": 0,
                "min_text_length": 0,
                "category_breakdown": {},
                "warnings": ["Dataset is currently empty."]
            }

        duplicate_records = [r for r in records if r.duplicate_flag]
        unique_records = total_records - len(duplicate_records)
        duplicate_ratio = (len(duplicate_records) / total_records) * 100.0

        dup_groups = set(r.duplicate_group_id for r in duplicate_records if r.duplicate_group_id)

        lengths = [r.length for r in records]
        avg_len = sum(lengths) / total_records if lengths else 0.0
        max_len = max(lengths) if lengths else 0
        min_len = min(lengths) if lengths else 0

        cat_counts = dict(Counter(r.category for r in records))

        # Threshold Warnings (Section 4 Stretch Feature)
        warnings = []
        if duplicate_ratio >= DUPLICATE_RATIO_WARNING_THRESHOLD:
            warnings.append(
                f"THRESHOLD WARNING: Duplicate ratio is high ({duplicate_ratio:.1f}%), exceeding limit of {DUPLICATE_RATIO_WARNING_THRESHOLD}%."
            )
        if total_records >= MAX_RECOMMENDED_RECORDS:
            warnings.append(
                f"VOLUME WARNING: Total record count ({total_records}) exceeds recommended limit ({MAX_RECOMMENDED_RECORDS}) for local file storage."
            )

        return {
            "total_records": total_records,
            "unique_records": unique_records,
            "duplicate_records": len(duplicate_records),
            "duplicate_ratio_pct": round(duplicate_ratio, 2),
            "duplicate_groups_count": len(dup_groups),
            "avg_text_length": round(avg_len, 2),
            "max_text_length": max_len,
            "min_text_length": min_len,
            "category_breakdown": cat_counts,
            "warnings": warnings
        }
