"""
Duplicate Text Finder (DTF) - Main Application Entry Point
Grounding: Problem Brief #106 (Digital Tools & Productivity)
Hackathon Mentor Guide Project #106

Core Features:
- Menu-driven Terminal Interface with ANSI formatting.
- Defensive input validation routines.
- Business Logic Engine for exact duplicate detection.
- JSON / CSV Data Persistence with recovery for corrupted files.
- Record Query & Search filtering.
- Executive Summary & Analytics Generation with Threshold Warnings.
- Multi-Format Export (Markdown, TXT Audit Log, CSV).
- Optional Tkinter GUI mode.
"""

import sys
import argparse
from pathlib import Path
from typing import List

from config import DEFAULT_JSON_PATH, DEFAULT_CSV_PATH, CATEGORIES, EXPORTS_DIR
from core.data_models import TextRecord
from core.finder_engine import FinderEngine
from core.persistence import PersistenceManager
from core.query_engine import QueryEngine
from core.summary import SummaryGenerator
from core.exporter import SummaryExporter
from core.validator import InputValidator

# ANSI Color Codes for branded Terminal Console
CLR_HEADER = "\033[95m\033[1m"
CLR_BLUE = "\033[94m"
CLR_GREEN = "\033[92m"
CLR_YELLOW = "\033[93m"
CLR_RED = "\033[91m"
CLR_RESET = "\033[0m"
CLR_BOLD = "\033[1m"

def print_welcome_banner():
    print(f"{CLR_HEADER}========================================================================")
    print("      🔍 DUPLICATE TEXT FINDER (DTF) - Python for Good #106")
    print("         Digital Tools & Productivity | Zero-Dependency Utility")
    print(f"========================================================================{CLR_RESET}")

def print_menu():
    print(f"\n{CLR_BOLD}--- MAIN MENU OPTIONS ---{CLR_RESET}")
    print(f"  [{CLR_GREEN}1{CLR_RESET}] ➕ Add New Text Entry (Interactive Validation)")
    print(f"  [{CLR_GREEN}2{CLR_RESET}] 📋 List & View All Stored Records")
    print(f"  [{CLR_GREEN}3{CLR_RESET}] 🔍 Query & Search Records (Filter by Keyword / Category / Status)")
    print(f"  [{CLR_GREEN}4{CLR_RESET}] 📊 View Executive Summary Analytics & Warnings")
    print(f"  [{CLR_GREEN}5{CLR_RESET}] 📁 Scan External File for Duplicate Lines")
    print(f"  [{CLR_GREEN}6{CLR_RESET}] 📤 Multi-Format Summary Export (Markdown / Audit Log / CSV)")
    print(f"  [{CLR_GREEN}7{CLR_RESET}] 🖥️  Launch Graphical User Interface (Tkinter GUI)")
    print(f"  [{CLR_GREEN}8{CLR_RESET}] 🔄 Switch Data File (Current: JSON/CSV)")
    print(f"  [{CLR_GREEN}9{CLR_RESET}] ❌ Exit Application")

class DTFTerminalApp:
    def __init__(self, data_file: Path = DEFAULT_JSON_PATH):
        self.data_file = data_file
        self.records: List[TextRecord] = []
        self.load_active_dataset()

    def load_active_dataset(self):
        if self.data_file.suffix.lower() == ".json":
            self.records, msg = PersistenceManager.load_from_json(self.data_file)
        else:
            self.records, msg = PersistenceManager.load_from_csv(self.data_file)

        self.records, self.dup_groups = FinderEngine.analyze_records(self.records)
        print(f"{CLR_BLUE}[System]{CLR_RESET} {msg}")

    def save_active_dataset(self):
        self.records, self.dup_groups = FinderEngine.analyze_records(self.records)
        if self.data_file.suffix.lower() == ".json":
            ok, msg = PersistenceManager.save_to_json(self.records, self.data_file)
        else:
            ok, msg = PersistenceManager.save_to_csv(self.records, self.data_file)
        if ok:
            print(f"{CLR_GREEN}[Success]{CLR_RESET} {msg}")
        else:
            print(f"{CLR_RED}[Error]{CLR_RESET} {msg}")

    def add_entry_interactive(self):
        print(f"\n{CLR_BOLD}=== ➕ Add New Text Entry ==={CLR_RESET}")
        text_content = InputValidator.prompt_valid_text("Enter text content: ")

        print("\nSelect Category:")
        for idx, cat in enumerate(CATEGORIES, start=1):
            print(f"  {idx}. {cat}")
        cat_idx_str = InputValidator.prompt_valid_menu_choice(
            "Select category (1-5): ", [str(i) for i in range(1, len(CATEGORIES) + 1)]
        )
        category = CATEGORIES[int(cat_idx_str) - 1]

        source_name = input("Enter Source Name/Tag (default: Terminal Entry): ").strip() or "Terminal Entry"
        notes = input("Enter optional notes: ").strip()

        rec_id = f"REC-{(len(self.records) + 1):03d}"
        new_rec = TextRecord(
            record_id=rec_id,
            text_content=text_content,
            category=category,
            source_name=source_name,
            notes=notes
        )

        self.records.append(new_rec)
        self.save_active_dataset()

        # Check if the newly saved entry turned out to be a duplicate
        if new_rec.duplicate_flag:
            print(f"\n{CLR_YELLOW}⚠️  DUPLICATE DETECTED!{CLR_RESET}")
            print(f"   Record '{new_rec.record_id}' matches existing content in group '{new_rec.duplicate_group_id}'.")
        else:
            print(f"\n{CLR_GREEN}✅ Record '{new_rec.record_id}' added as a CLEAN / UNIQUE entry.{CLR_RESET}")

    def list_records(self, records_to_show: List[TextRecord] = None):
        target = records_to_show if records_to_show is not None else self.records
        print(f"\n{CLR_BOLD}=== 📋 Stored Records ({len(target)} items) ==={CLR_RESET}")
        if not target:
            print("  [No records found matching criteria]")
            return

        print(f"{'ID':<8} | {'Status':<12} | {'Group ID':<12} | {'Category':<14} | {'Len':<5} | {'Source':<18} | {'Text Snippet'}")
        print("-" * 105)
        for r in target:
            st = f"{CLR_RED}DUPLICATE{CLR_RESET}" if r.duplicate_flag else f"{CLR_GREEN}UNIQUE{CLR_RESET}"
            grp = r.duplicate_group_id if r.duplicate_group_id else "-"
            snip = r.text_content.replace('\n', ' ')
            if len(snip) > 35:
                snip = snip[:32] + "..."
            print(f"{r.record_id:<8} | {st:<21} | {grp:<12} | {r.category:<14} | {r.length:<5} | {r.source_name:<18} | {snip}")

    def query_search_interactive(self):
        print(f"\n{CLR_BOLD}=== 🔍 Query & Search Records ==={CLR_RESET}")
        kw = input("Enter search keyword (leave blank to skip): ").strip()
        cat_filter = input(f"Enter Category filter ({'/'.join(CATEGORIES)} or blank for All): ").strip()
        status_choice = input("Filter status? (1: All, 2: Duplicates Only, 3: Unique Only): ").strip()

        dup_only = True if status_choice == "2" else (False if status_choice == "3" else None)
        filtered = QueryEngine.search_records(self.records, keyword=kw, category=cat_filter, duplicate_only=dup_only)
        self.list_records(filtered)

    def display_executive_summary(self):
        summary = SummaryGenerator.generate_summary(self.records)
        print(f"\n{CLR_HEADER}========================================================================")
        print("               📊 EXECUTIVE SUMMARY & SYSTEM ANALYTICS")
        print(f"========================================================================{CLR_RESET}")
        print(f" Total Records Analyzed:     {summary['total_records']}")
        print(f" Unique Entries:             {CLR_GREEN}{summary['unique_records']}{CLR_RESET}")
        print(f" Exact Duplicate Entries:    {CLR_RED}{summary['duplicate_records']}{CLR_RESET}")
        print(f" Duplicate Ratio (%):        {summary['duplicate_ratio_pct']}%")
        print(f" Duplicate Groups Count:     {summary['duplicate_groups_count']}")
        print("------------------------------------------------------------------------")
        print(f" Avg Text Length:            {summary['avg_text_length']} chars")
        print(f" Max Text Length:            {summary['max_text_length']} chars")
        print(f" Min Text Length:            {summary['min_text_length']} chars")
        print("------------------------------------------------------------------------")
        print(" Category Breakdown:")
        for cat, cnt in summary.get('category_breakdown', {}).items():
            print(f"   • {cat:<18}: {cnt} records")

        if summary.get('warnings'):
            print("------------------------------------------------------------------------")
            print(f"{CLR_YELLOW}SYSTEM WARNINGS:{CLR_RESET}")
            for w in summary['warnings']:
                print(f"   ⚠️  {w}")
        print(f"{CLR_HEADER}========================================================================{CLR_RESET}")

    def scan_external_file_interactive(self):
        print(f"\n{CLR_BOLD}=== 📁 Scan External Text File for Duplicate Lines ==={CLR_RESET}")
        file_path_str = input("Enter path to plain text/CSV file to scan: ").strip()
        is_valid, msg = InputValidator.validate_file_path(file_path_str, must_exist=True)
        if not is_valid:
            print(f"  {CLR_RED}[!]{CLR_RESET} {msg}")
            return

        results = FinderEngine.scan_file_for_duplicates(file_path_str)
        print(f"\n{CLR_BLUE}[Scan Complete]{CLR_RESET}")
        print(f" File: {results['file_path']}")
        print(f" Non-empty Lines Scanned: {results['total_non_empty_lines']}")
        print(f" Unique Lines:            {results['unique_lines_count']}")
        print(f" Duplicate Lines Count:   {results['duplicate_lines_count']}")
        print(f" Duplicate Groups:        {results['duplicate_groups_count']}")

        if results['duplicate_details']:
            print(f"\n{CLR_YELLOW}Duplicate Line Groups Detail:{CLR_RESET}")
            for idx, (norm_key, info) in enumerate(results['duplicate_details'].items(), start=1):
                print(f"  Group #{idx} ({info['occurrences']} occurrences) on lines {info['line_numbers']}:")
                print(f"    Text: \"{info['sample_text']}\"")

    def export_summary_interactive(self):
        summary = SummaryGenerator.generate_summary(self.records)
        print(f"\n{CLR_BOLD}=== 📤 Multi-Format Summary Export ==={CLR_RESET}")
        print("1. Markdown Summary Report (.md)")
        print("2. Plain-Text System Audit Log (.txt)")
        print("3. CSV Standardized Dataset (.csv)")
        print("4. Export All Formats")

        ch = InputValidator.prompt_valid_menu_choice("Select option (1-4): ", ["1", "2", "3", "4"])

        if ch in ["1", "4"]:
            ok, msg = SummaryExporter.export_markdown_summary(summary, self.records, EXPORTS_DIR / "executive_summary.md")
            print(f"  [{'✅' if ok else '❌'}] {msg}")
        if ch in ["2", "4"]:
            ok, msg = SummaryExporter.export_text_audit_log(self.records, summary, EXPORTS_DIR / "system_audit_log.txt")
            print(f"  [{'✅' if ok else '❌'}] {msg}")
        if ch in ["3", "4"]:
            ok, msg = SummaryExporter.export_csv_report(self.records, EXPORTS_DIR / "records_export.csv")
            print(f"  [{'✅' if ok else '❌'}] {msg}")

    def run_menu_loop(self):
        print_welcome_banner()
        while True:
            print_menu()
            choice = input(f"\n{CLR_BOLD}Enter choice (1-9): {CLR_RESET}").strip()
            if choice == "1":
                self.add_entry_interactive()
            elif choice == "2":
                self.list_records()
            elif choice == "3":
                self.query_search_interactive()
            elif choice == "4":
                self.display_executive_summary()
            elif choice == "5":
                self.scan_external_file_interactive()
            elif choice == "6":
                self.export_summary_interactive()
            elif choice == "7":
                print(f"{CLR_BLUE}[Launching GUI] Opening Tkinter window...{CLR_RESET}")
                try:
                    import tkinter as tk
                    from gui.app_gui import DTFGuiApp
                    root = tk.Tk()
                    app = DTFGuiApp(root)
                    root.mainloop()
                except Exception as err:
                    print(f"{CLR_RED}GUI Launch Error: {str(err)}. (Requires display server/Tkinter).{CLR_RESET}")
            elif choice == "8":
                print("\n1. JSON dataset ('sample_records.json')")
                print("2. CSV dataset ('sample_records.csv')")
                sub_ch = input("Select format (1 or 2): ").strip()
                self.data_file = DEFAULT_JSON_PATH if sub_ch == "1" else DEFAULT_CSV_PATH
                self.load_active_dataset()
            elif choice == "9":
                print(f"\n{CLR_GREEN}Thank you for using Duplicate Text Finder! Exiting program.{CLR_RESET}")
                sys.exit(0)
            else:
                print(f"{CLR_RED}Invalid option '{choice}'. Please select 1-9.{CLR_RESET}")

def main():
    parser = argparse.ArgumentParser(description="Duplicate Text Finder (DTF) - Hackathon Project #106")
    parser.add_argument("--gui", action="store_true", help="Launch directly in Tkinter GUI mode")
    parser.add_argument("--csv", action="store_true", help="Use CSV storage instead of default JSON")
    args = parser.parse_args()

    data_file = DEFAULT_CSV_PATH if args.csv else DEFAULT_JSON_PATH

    if args.gui:
        import tkinter as tk
        from gui.app_gui import DTFGuiApp
        root = tk.Tk()
        app = DTFGuiApp(root)
        root.mainloop()
    else:
        app = DTFTerminalApp(data_file=data_file)
        app.run_menu_loop()

if __name__ == "__main__":
    main()
