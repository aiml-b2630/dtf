"""
Duplicate Text Finder (DTF) - Configuration & Constants
Grounding Source: Problem Brief #106 (Digital Tools & Productivity)
"""

import os
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
EXPORTS_DIR = BASE_DIR / "exports"

DATA_DIR.mkdir(exist_ok=True)
EXPORTS_DIR.mkdir(exist_ok=True)

DEFAULT_CSV_PATH = DATA_DIR / "sample_records.csv"
DEFAULT_JSON_PATH = DATA_DIR / "sample_records.json"

# Threshold Warning Limits (Section 4 Stretch Feature)
DUPLICATE_RATIO_WARNING_THRESHOLD = 25.0  # Percentage (%) above which warning triggers
MAX_RECOMMENDED_RECORDS = 1000            # Warning limit for local dataset scale

# Standard Categories
CATEGORIES = [
    "Academic",
    "Code Snippet",
    "Productivity",
    "Documentation",
    "General"
]
