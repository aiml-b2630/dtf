# Duplicate Text Finder (DTF)
> **Hackathon Mentor Guide Project #106** | *Domain: Digital Tools & Productivity*  
> Grounded in Problem Brief specifications from `6af5e80fa37d855e28cc82ee.pdf`.

---

## 📌 1. Project Overview & Problem Context
In academic and everyday environments, stakeholders frequently experience friction when attempting to compare text entries and flag exact duplicates in a list or file manually or with fragmented tools. **Duplicate Text Finder (DTF)** is a focused, accessible Python application engineered to streamline data handling, validate entries, and present actionable summaries.

---

## 🚀 2. Core Features (Must-Have Implementation)
All must-have core requirements specified in **Section 3** of the brief are fully implemented:

1. **Interactive Terminal Console Interface (`main.py`):**
   - Menu-driven command prompt with ANSI color formatting (`CLR_HEADER`, `CLR_GREEN`, `CLR_YELLOW`, `CLR_RED`).
2. **Defensive Input Validation (`core/validator.py`):**
   - Real-time sanitization, control character removal, non-blank checks, and range bounds.
3. **Core Business Logic Engine (`core/finder_engine.py`):**
   - Standardized text normalization (case-insensitive, whitespace collapsing), SHA-256 content hashing, and exact duplicate group indexing.
4. **Local Data Persistence (`core/persistence.py`):**
   - Automated reading and writing of JSON (`sample_records.json`) and CSV (`sample_records.csv`).
   - Fault-tolerant initialization: auto-detects `FileNotFoundError` or corrupted files (`JSONDecodeError`), creating clean initial templates.
5. **Record Query & Search (`core/query_engine.py`):**
   - Filtering by keyword, category (`Academic`, `Code Snippet`, `Productivity`, `Documentation`, `General`), and duplicate status (`Duplicates Only`, `Unique Only`).
6. **Executive Summary & Analytics (`core/summary.py`):**
   - Computes total records, unique count, duplicate ratio (%), group counts, average/min/max text length, and category breakdowns.

---

## ⭐ 3. Stretch Features (Good-to-Have Implementation)
All stretch features specified in **Section 4** of the brief are included:

1. **Multi-Format Summary Export (`core/exporter.py`):**
   - **Markdown Report (`executive_summary.md`):** Formatted report with KPIs, tables, and warnings.
   - **Plain-Text System Audit Log (`system_audit_log.txt`):** Time-stamped audit trail detailing content hashes and status flags.
   - **CSV Export (`records_export.csv`):** Standardized tabular output for external software review.
2. **Threshold Warning Indicators (`config.py` & `core/summary.py`):**
   - Automated console warning flags triggering when duplicate ratio exceeds `25.0%` or record volume approaches high thresholds (`1,000` items).
3. **Interactive Graphical Interface (Tkinter GUI in `gui/app_gui.py`):**
   - Complete GUI tab navigation for searching, adding entries, visual table views, and quick exports.
4. **External File & Dataset Bulk Scanner (`FinderEngine.scan_file_for_duplicates`):**
   - Line-by-line scanning of arbitrary external plain-text/CSV files to flag exact duplicate lines with line numbers and sample text.

---

## 🛠️ 4. Tech Stack & Zero-Dependency Execution
- **Python Version:** Python 3.10+ Standard Library (zero external dependencies).
- **Standard Modules Used:** `json`, `csv`, `hashlib`, `dataclasses`, `datetime`, `re`, `argparse`, `tkinter`, `unittest`, `pathlib`, `collections`.

---

## 📂 5. Directory Architecture
```
duplicate_text_finder/
│
├── main.py                  # Primary Terminal Console & GUI Launcher
├── config.py                # System settings & warning thresholds
├── generate_samples.py      # Seed script for 40 realistic sample records
├── requirements.txt         # Zero-dependency specification file
├── README.md                # Project documentation & source mapping
│
├── core/
│   ├── __init__.py
│   ├── data_models.py       # Data structures & Dataclasses (TextRecord)
│   ├── finder_engine.py     # Business logic, SHA-256 hash matching, line scanner
│   ├── validator.py         # Defensive input validation & sanitization
│   ├── persistence.py       # JSON / CSV reading, writing, and corrupt file recovery
│   ├── query_engine.py      # Keyword, category, and duplicate status search
│   ├── summary.py           # Executive summary calculation & threshold warnings
│   └── exporter.py          # Markdown, TXT audit log, and CSV exports
│
├── gui/
│   ├── __init__.py
│   └── app_gui.py           # Tkinter GUI application
│
├── data/
│   ├── sample_records.json  # 40 realistic sample records (JSON)
│   └── sample_records.csv   # 40 realistic sample records (CSV)
│
└── tests/
    ├── __init__.py
    └── test_dtf.py          # Unit & End-to-End test suite
```

---

## 🚀 6. Quick Start & Execution Guide

### Launch Interactive Terminal Menu:
```bash
python3 main.py
```

### Launch Interactive Tkinter GUI:
```bash
python3 main.py --gui
# OR
python3 gui/app_gui.py
```

### Run Automated Unit Test Suite:
```bash
python3 tests/test_dtf.py
```

### Re-generate Sample Data (40 Records):
```bash
python3 generate_samples.py
```

---

## 🎬 7. Demonstrating the Hackathon Demo Journey (Section 9)
1. **Launch:** Run `python3 main.py` to display the branded welcome screen.
2. **Defensive Validation:** Choose option `1` to add an entry. Intentionally submit empty whitespace or non-conforming inputs to observe defensive error catching.
3. **Duplicate Detection:** Submit text identical to an existing sample entry (e.g. *"In academic and everyday environments, stakeholders frequently experience friction..."*) and watch the system instantly flag `⚠️ DUPLICATE DETECTED!` with group indexing.
4. **Executive Analytics:** Select option `4` to view key metrics, duplicate percentages, category breakdowns, and threshold breach warnings.
5. **State Preservation:** Close the application (`option 9`) and relaunch (`python3 main.py`) to confirm local JSON/CSV data persistence.
6. **Multi-Format Export:** Select option `6` to generate Markdown reports and TXT audit logs.
